/*
  # Attendance Manager Database Schema

  ## Overview
  Creates the complete database schema for the Bank Teller Attendance Manager application.

  ## New Tables
  
  ### 1. `profiles`
  Extended user profile information for bank tellers:
  - `id` (uuid, FK to auth.users) - Primary key linked to auth
  - `full_name` (text) - Full name with initials
  - `nickname` (text) - Preferred nickname
  - `teller_id` (text, unique) - Unique teller identifier
  - `team` (text) - Team assignment (Team1/Team2/Team3)
  - `mobile_number` (text) - Contact number
  - `pf_number` (text) - PF number
  - `basic_salary` (numeric) - Basic salary amount
  - `created_at` (timestamptz) - Record creation timestamp
  - `updated_at` (timestamptz) - Last update timestamp

  ### 2. `roster`
  Daily shift and booth assignments for all teams:
  - `id` (uuid) - Primary key
  - `date` (date) - Roster date
  - `teller_id` (text) - Reference to teller
  - `team` (text) - Team name
  - `shift` (text) - Shift type (Day/Night/Off)
  - `booth` (text) - Booth assignment
  - `created_at` (timestamptz) - Record creation timestamp
  - Unique constraint on (date, teller_id)

  ### 3. `attendance`
  Actual attendance records with arrival/departure times:
  - `id` (uuid) - Primary key
  - `user_id` (uuid, FK to profiles) - User reference
  - `date` (date) - Attendance date
  - `shift` (text) - Actual shift worked
  - `booth` (text) - Booth assignment
  - `arrival_time` (time) - Actual arrival time
  - `departure_time` (time) - Actual departure time
  - `work_hours` (numeric) - Total hours worked
  - `ot_hours` (numeric) - Overtime hours
  - `is_late` (boolean) - Late arrival flag
  - `is_short_leave` (boolean) - Short leave flag
  - `is_half_day` (boolean) - Half day flag
  - `notes` (text) - Additional notes
  - `created_at` (timestamptz) - Record creation timestamp
  - `updated_at` (timestamptz) - Last update timestamp
  - Unique constraint on (user_id, date)

  ## Security
  - Enable RLS on all tables
  - Users can read their own profile and attendance
  - Users can read roster for all teams
  - Users can update their own attendance records
  - Admins can manage all data (future enhancement)
*/

-- Create profiles table
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name text NOT NULL,
  nickname text,
  teller_id text UNIQUE NOT NULL,
  team text NOT NULL CHECK (team IN ('Team1', 'Team2', 'Team3')),
  mobile_number text,
  pf_number text,
  basic_salary numeric DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create roster table
CREATE TABLE IF NOT EXISTS roster (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  date date NOT NULL,
  teller_id text NOT NULL,
  team text NOT NULL CHECK (team IN ('Team1', 'Team2', 'Team3')),
  shift text NOT NULL CHECK (shift IN ('Day', 'Night', 'Off')),
  booth text,
  created_at timestamptz DEFAULT now(),
  UNIQUE(date, teller_id)
);

-- Create attendance table
CREATE TABLE IF NOT EXISTS attendance (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  date date NOT NULL,
  shift text NOT NULL CHECK (shift IN ('Day', 'Night', 'Off')),
  booth text,
  arrival_time time,
  departure_time time,
  work_hours numeric DEFAULT 0,
  ot_hours numeric DEFAULT 0,
  is_late boolean DEFAULT false,
  is_short_leave boolean DEFAULT false,
  is_half_day boolean DEFAULT false,
  notes text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(user_id, date)
);

-- Create indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_roster_date ON roster(date);
CREATE INDEX IF NOT EXISTS idx_roster_teller_id ON roster(teller_id);
CREATE INDEX IF NOT EXISTS idx_roster_team ON roster(team);
CREATE INDEX IF NOT EXISTS idx_attendance_user_id ON attendance(user_id);
CREATE INDEX IF NOT EXISTS idx_attendance_date ON attendance(date);
CREATE INDEX IF NOT EXISTS idx_attendance_user_date ON attendance(user_id, date);

-- Enable Row Level Security
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE roster ENABLE ROW LEVEL SECURITY;
ALTER TABLE attendance ENABLE ROW LEVEL SECURITY;

-- Profiles policies
CREATE POLICY "Users can read own profile"
  ON profiles FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can update own profile"
  ON profiles FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

CREATE POLICY "Users can insert own profile"
  ON profiles FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = id);

-- Roster policies (all authenticated users can read roster)
CREATE POLICY "Authenticated users can read roster"
  ON roster FOR SELECT
  TO authenticated
  USING (true);

-- Attendance policies
CREATE POLICY "Users can read own attendance"
  ON attendance FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Users can insert own attendance"
  ON attendance FOR INSERT
  TO authenticated
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "Users can update own attendance"
  ON attendance FOR UPDATE
  TO authenticated
  USING (user_id = auth.uid())
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "Users can delete own attendance"
  ON attendance FOR DELETE
  TO authenticated
  USING (user_id = auth.uid());

-- Function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Create triggers for updated_at
CREATE TRIGGER update_profiles_updated_at BEFORE UPDATE ON profiles
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_attendance_updated_at BEFORE UPDATE ON attendance
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
