export type ShiftType = 'Day' | 'Night' | 'Off';
export type TeamType = 'Team1' | 'Team2' | 'Team3';

export interface Database {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string;
          full_name: string;
          nickname: string | null;
          teller_id: string;
          team: TeamType;
          mobile_number: string | null;
          pf_number: string | null;
          basic_salary: number;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id: string;
          full_name: string;
          nickname?: string | null;
          teller_id: string;
          team: TeamType;
          mobile_number?: string | null;
          pf_number?: string | null;
          basic_salary?: number;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          full_name?: string;
          nickname?: string | null;
          teller_id?: string;
          team?: TeamType;
          mobile_number?: string | null;
          pf_number?: string | null;
          basic_salary?: number;
          created_at?: string;
          updated_at?: string;
        };
      };
      roster: {
        Row: {
          id: string;
          date: string;
          teller_id: string;
          team: TeamType;
          shift: ShiftType;
          booth: string | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          date: string;
          teller_id: string;
          team: TeamType;
          shift: ShiftType;
          booth?: string | null;
          created_at?: string;
        };
        Update: {
          id?: string;
          date?: string;
          teller_id?: string;
          team?: TeamType;
          shift?: ShiftType;
          booth?: string | null;
          created_at?: string;
        };
      };
      attendance: {
        Row: {
          id: string;
          user_id: string;
          date: string;
          shift: ShiftType;
          booth: string | null;
          arrival_time: string | null;
          departure_time: string | null;
          work_hours: number;
          ot_hours: number;
          is_late: boolean;
          is_short_leave: boolean;
          is_half_day: boolean;
          notes: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          date: string;
          shift: ShiftType;
          booth?: string | null;
          arrival_time?: string | null;
          departure_time?: string | null;
          work_hours?: number;
          ot_hours?: number;
          is_late?: boolean;
          is_short_leave?: boolean;
          is_half_day?: boolean;
          notes?: string | null;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          user_id?: string;
          date?: string;
          shift?: ShiftType;
          booth?: string | null;
          arrival_time?: string | null;
          departure_time?: string | null;
          work_hours?: number;
          ot_hours?: number;
          is_late?: boolean;
          is_short_leave?: boolean;
          is_half_day?: boolean;
          notes?: string | null;
          created_at?: string;
          updated_at?: string;
        };
      };
    };
  };
}

export type Profile = Database['public']['Tables']['profiles']['Row'];
export type Roster = Database['public']['Tables']['roster']['Row'];
export type Attendance = Database['public']['Tables']['attendance']['Row'];
