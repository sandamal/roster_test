import { ShiftType } from '../lib/database.types';

export interface TimeCalculation {
  workHours: number;
  otHours: number;
  isLate: boolean;
  isShortLeave: boolean;
  isHalfDay: boolean;
}

export function roundTimeUp(time: string): string {
  const [hours, minutes] = time.split(':').map(Number);
  const roundedMinutes = Math.ceil(minutes / 15) * 15;

  if (roundedMinutes === 60) {
    return `${String((hours + 1) % 24).padStart(2, '0')}:00`;
  }

  return `${String(hours).padStart(2, '0')}:${String(roundedMinutes).padStart(2, '0')}`;
}

export function roundTimeDown(time: string): string {
  const [hours, minutes] = time.split(':').map(Number);
  const roundedMinutes = Math.floor(minutes / 15) * 15;

  return `${String(hours).padStart(2, '0')}:${String(roundedMinutes).padStart(2, '0')}`;
}

export function getDefaultShiftTimes(shift: ShiftType): { arrival: string; departure: string } {
  if (shift === 'Day') {
    return { arrival: '06:30', departure: '19:30' };
  } else if (shift === 'Night') {
    return { arrival: '18:30', departure: '07:30' };
  }
  return { arrival: '', departure: '' };
}

export function calculateTimeDifferenceInHours(startTime: string, endTime: string): number {
  const [startHour, startMin] = startTime.split(':').map(Number);
  const [endHour, endMin] = endTime.split(':').map(Number);

  let startMinutes = startHour * 60 + startMin;
  let endMinutes = endHour * 60 + endMin;

  if (endMinutes < startMinutes) {
    endMinutes += 24 * 60;
  }

  const diffMinutes = endMinutes - startMinutes;
  return diffMinutes / 60;
}

export function isTimeInRange(time: string, startRange: string, endRange: string): boolean {
  const [hour, min] = time.split(':').map(Number);
  const [startHour, startMin] = startRange.split(':').map(Number);
  const [endHour, endMin] = endRange.split(':').map(Number);

  const timeMinutes = hour * 60 + min;
  const startMinutes = startHour * 60 + startMin;
  const endMinutes = endHour * 60 + endMin;

  return timeMinutes >= startMinutes && timeMinutes <= endMinutes;
}

export function isLateArrival(arrivalTime: string, shift: ShiftType): boolean {
  if (shift === 'Day') {
    return isTimeInRange(arrivalTime, '06:30', '06:45');
  } else if (shift === 'Night') {
    return isTimeInRange(arrivalTime, '18:30', '18:45');
  }
  return false;
}

export function isShortLeave(arrivalTime: string | null, departureTime: string | null, shift: ShiftType): boolean {
  if (!arrivalTime || !departureTime) return false;

  const defaultTimes = getDefaultShiftTimes(shift);
  const arrivalDiff = calculateTimeDifferenceInHours(defaultTimes.arrival, arrivalTime);
  const departureDiff = calculateTimeDifferenceInHours(departureTime, defaultTimes.departure);

  return Math.abs(arrivalDiff) >= 1.5 || Math.abs(departureDiff) >= 1.5;
}

export function isHalfDay(arrivalTime: string | null, departureTime: string | null): boolean {
  if (!arrivalTime && !departureTime) return false;

  if (arrivalTime) {
    const arrivalHour = parseInt(arrivalTime.split(':')[0]);
    if (arrivalHour === 12) return true;
  }

  if (departureTime) {
    const [departureHour, departureMin] = departureTime.split(':').map(Number);
    if (departureHour === 1 || (departureHour === 13 && departureMin === 0)) return true;
  }

  return false;
}

export function calculateAttendance(
  arrivalTime: string | null,
  departureTime: string | null,
  shift: ShiftType
): TimeCalculation {
  if (!arrivalTime || !departureTime || shift === 'Off') {
    return {
      workHours: 0,
      otHours: 0,
      isLate: false,
      isShortLeave: false,
      isHalfDay: false,
    };
  }

  const roundedArrival = roundTimeUp(arrivalTime);
  const roundedDeparture = roundTimeDown(departureTime);

  const workHours = calculateTimeDifferenceInHours(roundedArrival, roundedDeparture);
  const otHours = workHours > 8 ? workHours - 8 : 0;

  return {
    workHours: Math.max(0, workHours),
    otHours: Math.max(0, otHours),
    isLate: isLateArrival(arrivalTime, shift),
    isShortLeave: isShortLeave(arrivalTime, departureTime, shift),
    isHalfDay: isHalfDay(arrivalTime, departureTime),
  };
}

export interface MonthlyAggregation {
  totalLates: number;
  totalShortLeaves: number;
  totalHalfDays: number;
  aggregatedShortLeaves: number;
  aggregatedHalfDays: number;
  totalOTHours: number;
  totalWorkHours: number;
}

export function aggregateMonthlyAttendance(attendanceRecords: Array<{
  is_late: boolean;
  is_short_leave: boolean;
  is_half_day: boolean;
  ot_hours: number;
  work_hours: number;
}>): MonthlyAggregation {
  let totalLates = 0;
  let totalShortLeaves = 0;
  let totalHalfDays = 0;
  let totalOTHours = 0;
  let totalWorkHours = 0;

  attendanceRecords.forEach(record => {
    if (record.is_late) totalLates++;
    if (record.is_short_leave) totalShortLeaves++;
    if (record.is_half_day) totalHalfDays++;
    totalOTHours += record.ot_hours;
    totalWorkHours += record.work_hours;
  });

  const additionalShortLeavesFromLates = Math.floor(totalLates / 4);
  const additionalHalfDaysFromShortLeaves = Math.floor((totalShortLeaves + additionalShortLeavesFromLates) / 2);

  return {
    totalLates,
    totalShortLeaves,
    totalHalfDays,
    aggregatedShortLeaves: totalShortLeaves + additionalShortLeavesFromLates,
    aggregatedHalfDays: totalHalfDays + additionalHalfDaysFromShortLeaves,
    totalOTHours: Math.round(totalOTHours * 100) / 100,
    totalWorkHours: Math.round(totalWorkHours * 100) / 100,
  };
}

export function formatDate(date: Date): string {
  return date.toISOString().split('T')[0];
}

export function formatDateDisplay(dateStr: string): string {
  const date = new Date(dateStr);
  return date.toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });
}
