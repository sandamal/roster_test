import { useState, useEffect } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { supabase } from '../../lib/supabase';
import { Attendance, Roster } from '../../lib/database.types';
import { UserProfile } from './UserProfile';
import { DateNavigation } from './DateNavigation';
import { DarkModeToggle } from './DarkModeToggle';
import { AttendanceTable } from '../Attendance/AttendanceTable';
import { MonthlySummary } from '../Attendance/MonthlySummary';
import { Printer } from 'lucide-react';
import {
  calculateAttendance,
  aggregateMonthlyAttendance,
  getDefaultShiftTimes,
} from '../../utils/attendanceCalculations';

export function Dashboard() {
  const { profile, signOut } = useAuth();
  const [currentDate, setCurrentDate] = useState(new Date());
  const [attendanceRecords, setAttendanceRecords] = useState<Attendance[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (profile) {
      loadMonthlyAttendance();
    }
  }, [profile, currentDate]);

  const loadMonthlyAttendance = async () => {
    if (!profile) return;

    setLoading(true);
    try {
      const year = currentDate.getFullYear();
      const month = currentDate.getMonth();
      const startDate = new Date(year, month, 1).toISOString().split('T')[0];
      const endDate = new Date(year, month + 1, 0).toISOString().split('T')[0];

      const { data: existingAttendance, error: attendanceError } = await supabase
        .from('attendance')
        .select('*')
        .eq('user_id', profile.id)
        .gte('date', startDate)
        .lte('date', endDate)
        .order('date', { ascending: true });

      if (attendanceError) throw attendanceError;

      const { data: rosterData, error: rosterError } = await supabase
        .from('roster')
        .select('*')
        .eq('teller_id', profile.teller_id)
        .gte('date', startDate)
        .lte('date', endDate)
        .order('date', { ascending: true });

      if (rosterError) throw rosterError;

      const attendanceMap = new Map(
        (existingAttendance || []).map(att => [att.date, att])
      );

      const missingDates: Roster[] = [];
      (rosterData || []).forEach(roster => {
        if (!attendanceMap.has(roster.date)) {
          missingDates.push(roster);
        }
      });

      if (missingDates.length > 0) {
        const newAttendanceRecords = missingDates.map(roster => {
          const defaultTimes = getDefaultShiftTimes(roster.shift);
          return {
            user_id: profile.id,
            date: roster.date,
            shift: roster.shift,
            booth: roster.booth,
            arrival_time: defaultTimes.arrival || null,
            departure_time: defaultTimes.departure || null,
            work_hours: 0,
            ot_hours: 0,
            is_late: false,
            is_short_leave: false,
            is_half_day: false,
          };
        });

        const { error: insertError } = await supabase
          .from('attendance')
          .insert(newAttendanceRecords);

        if (insertError) throw insertError;

        const { data: updatedAttendance, error: refetchError } = await supabase
          .from('attendance')
          .select('*')
          .eq('user_id', profile.id)
          .gte('date', startDate)
          .lte('date', endDate)
          .order('date', { ascending: true });

        if (refetchError) throw refetchError;
        setAttendanceRecords(updatedAttendance || []);
      } else {
        setAttendanceRecords(existingAttendance || []);
      }
    } catch (error) {
      console.error('Error loading attendance:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateAttendance = async (id: string, arrivalTime: string, departureTime: string) => {
    const record = attendanceRecords.find(att => att.id === id);
    if (!record) return;

    const calculations = calculateAttendance(arrivalTime, departureTime, record.shift);

    const { error } = await supabase
      .from('attendance')
      .update({
        arrival_time: arrivalTime,
        departure_time: departureTime,
        work_hours: calculations.workHours,
        ot_hours: calculations.otHours,
        is_late: calculations.isLate,
        is_short_leave: calculations.isShortLeave,
        is_half_day: calculations.isHalfDay,
      })
      .eq('id', id);

    if (error) throw error;

    await loadMonthlyAttendance();
  };

  const handlePrint = () => {
    const monthYear = currentDate.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
    const printWindow = window.open('', '_blank');
    if (!printWindow) return;

    const summary = aggregateMonthlyAttendance(attendanceRecords);

    printWindow.document.write(`
      <!DOCTYPE html>
      <html>
        <head>
          <title>Attendance Report - ${monthYear}</title>
          <style>
            body { font-family: Arial, sans-serif; padding: 20px; }
            h1 { text-align: center; margin-bottom: 5px; }
            h2 { text-align: center; margin-top: 0; color: #666; }
            table { width: 100%; border-collapse: collapse; margin-top: 20px; }
            th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
            th { background-color: #f2f2f2; }
            .summary { margin-top: 30px; padding: 15px; background-color: #f9f9f9; border-radius: 5px; }
            .summary-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; margin-top: 10px; }
            .summary-item { padding: 10px; background: white; border-radius: 5px; }
            .summary-item label { font-size: 12px; color: #666; display: block; margin-bottom: 5px; }
            .summary-item value { font-size: 20px; font-weight: bold; }
          </style>
        </head>
        <body>
          <h1>Gelanigama Interchange ${profile?.team}</h1>
          <h2>Attendance Report - ${monthYear}</h2>
          <table>
            <thead>
              <tr>
                <th>Date</th>
                <th>Shift</th>
                <th>Booth</th>
                <th>Arrival</th>
                <th>Departure</th>
                <th>OT Hours</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              ${attendanceRecords.map(att => `
                <tr>
                  <td>${new Date(att.date).toLocaleDateString()}</td>
                  <td>${att.shift}</td>
                  <td>${att.booth || '-'}</td>
                  <td>${att.arrival_time || '-'}</td>
                  <td>${att.departure_time || '-'}</td>
                  <td>${att.ot_hours.toFixed(2)}</td>
                  <td>${[
                    att.is_late ? 'Late' : '',
                    att.is_short_leave ? 'Short Leave' : '',
                    att.is_half_day ? 'Half Day' : ''
                  ].filter(Boolean).join(', ') || '-'}</td>
                </tr>
              `).join('')}
            </tbody>
          </table>
          <div class="summary">
            <h3>Monthly Summary</h3>
            <div class="summary-grid">
              <div class="summary-item">
                <label>Total Work Hours</label>
                <value>${summary.totalWorkHours}</value>
              </div>
              <div class="summary-item">
                <label>Total OT Hours</label>
                <value>${summary.totalOTHours}</value>
              </div>
              <div class="summary-item">
                <label>Total Lates</label>
                <value>${summary.totalLates}</value>
              </div>
              <div class="summary-item">
                <label>Short Leaves (Aggregated)</label>
                <value>${summary.aggregatedShortLeaves}</value>
              </div>
              <div class="summary-item">
                <label>Half Days (Aggregated)</label>
                <value>${summary.aggregatedHalfDays}</value>
              </div>
            </div>
          </div>
        </body>
      </html>
    `);
    printWindow.document.close();
    printWindow.print();
  };

  const summary = aggregateMonthlyAttendance(attendanceRecords);
  const monthYear = currentDate.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });

  if (!profile) return null;

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 transition-colors">
      <div className="max-w-7xl mx-auto px-4 py-6">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
            Attendance Manager
          </h1>
          <DarkModeToggle />
        </div>

        <UserProfile profile={profile} onSignOut={signOut} />

        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 mb-6">
          <div className="flex items-center justify-between mb-6">
            <DateNavigation
              currentDate={currentDate}
              onPreviousMonth={() => setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1))}
              onNextMonth={() => setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1))}
              onToday={() => setCurrentDate(new Date())}
            />
            <button
              onClick={handlePrint}
              className="flex items-center gap-2 px-4 py-2 bg-gray-600 hover:bg-gray-700 text-white rounded-lg transition-colors text-sm font-medium"
            >
              <Printer size={16} />
              Print
            </button>
          </div>

          {loading ? (
            <div className="text-center py-8">
              <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
              <p className="mt-2 text-gray-600 dark:text-gray-400">Loading attendance...</p>
            </div>
          ) : (
            <AttendanceTable
              attendanceRecords={attendanceRecords}
              onUpdateAttendance={handleUpdateAttendance}
            />
          )}
        </div>

        <MonthlySummary summary={summary} month={monthYear} />
      </div>
    </div>
  );
}
