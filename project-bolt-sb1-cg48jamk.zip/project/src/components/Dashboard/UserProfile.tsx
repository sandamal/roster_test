import { Profile } from '../../lib/database.types';
import { User, LogOut } from 'lucide-react';

interface UserProfileProps {
  profile: Profile;
  onSignOut: () => void;
}

export function UserProfile({ profile, onSignOut }: UserProfileProps) {
  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 mb-6">
      <div className="flex items-start justify-between">
        <div className="flex items-start gap-4">
          <div className="w-16 h-16 bg-blue-600 dark:bg-blue-500 rounded-full flex items-center justify-center">
            <User className="w-8 h-8 text-white" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-gray-900 dark:text-white">{profile.full_name}</h2>
            {profile.nickname && (
              <p className="text-sm text-gray-600 dark:text-gray-400">({profile.nickname})</p>
            )}
            <div className="mt-2 grid grid-cols-2 gap-x-6 gap-y-1 text-sm">
              <div>
                <span className="text-gray-600 dark:text-gray-400">Teller ID:</span>
                <span className="ml-2 font-medium text-gray-900 dark:text-white">{profile.teller_id}</span>
              </div>
              <div>
                <span className="text-gray-600 dark:text-gray-400">Team:</span>
                <span className="ml-2 font-medium text-gray-900 dark:text-white">{profile.team}</span>
              </div>
              {profile.mobile_number && (
                <div>
                  <span className="text-gray-600 dark:text-gray-400">Mobile:</span>
                  <span className="ml-2 font-medium text-gray-900 dark:text-white">{profile.mobile_number}</span>
                </div>
              )}
              {profile.pf_number && (
                <div>
                  <span className="text-gray-600 dark:text-gray-400">PF Number:</span>
                  <span className="ml-2 font-medium text-gray-900 dark:text-white">{profile.pf_number}</span>
                </div>
              )}
            </div>
          </div>
        </div>
        <button
          onClick={onSignOut}
          className="flex items-center gap-2 px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg transition-colors text-sm font-medium"
        >
          <LogOut size={16} />
          Sign Out
        </button>
      </div>
    </div>
  );
}
