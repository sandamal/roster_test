import { useState } from 'react';
import { Attendance } from '../../lib/database.types';
import { Edit2, Save, X } from 'lucide-react';

interface AttendanceRowProps {
  attendance: Attendance;
  onUpdate: (id: string, arrivalTime: string, departureTime: string) => Promise<void>;
}

export function AttendanceRow({ attendance, onUpdate }: AttendanceRowProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [arrivalTime, setArrivalTime] = useState(attendance.arrival_time || '');
  const [departureTime, setDepartureTime] = useState(attendance.departure_time || '');
  const [saving, setSaving] = useState(false);

  const handleSave = async () => {
    setSaving(true);
    try {
      await onUpdate(attendance.id, arrivalTime, departureTime);
      setIsEditing(false);
    } catch (error) {
      console.error('Failed to update attendance:', error);
    } finally {
      setSaving(false);
    }
  };

  const handleCancel = () => {
    setArrivalTime(attendance.arrival_time || '');
    setDepartureTime(attendance.departure_time || '');
    setIsEditing(false);
  };

  const date = new Date(attendance.date);
  const formattedDate = date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });

  return (
    <tr className="border-b border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700/50">
      <td className="px-4 py-3 text-sm text-gray-900 dark:text-white">{formattedDate}</td>
      <td className="px-4 py-3 text-sm">
        <span className={`px-2 py-1 rounded text-xs font-medium ${
          attendance.shift === 'Day' ? 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400' :
          attendance.shift === 'Night' ? 'bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400' :
          'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-400'
        }`}>
          {attendance.shift}
        </span>
      </td>
      <td className="px-4 py-3 text-sm text-gray-700 dark:text-gray-300">{attendance.booth || '-'}</td>
      <td className="px-4 py-3 text-sm">
        {isEditing ? (
          <input
            type="time"
            value={arrivalTime}
            onChange={(e) => setArrivalTime(e.target.value)}
            className="px-2 py-1 border border-gray-300 dark:border-gray-600 rounded dark:bg-gray-700 dark:text-white text-sm"
          />
        ) : (
          <span className="text-gray-900 dark:text-white">{attendance.arrival_time || '-'}</span>
        )}
      </td>
      <td className="px-4 py-3 text-sm">
        {isEditing ? (
          <input
            type="time"
            value={departureTime}
            onChange={(e) => setDepartureTime(e.target.value)}
            className="px-2 py-1 border border-gray-300 dark:border-gray-600 rounded dark:bg-gray-700 dark:text-white text-sm"
          />
        ) : (
          <span className="text-gray-900 dark:text-white">{attendance.departure_time || '-'}</span>
        )}
      </td>
      <td className="px-4 py-3 text-sm font-medium text-green-600 dark:text-green-400">
        {attendance.ot_hours.toFixed(2)}
      </td>
      <td className="px-4 py-3 text-sm">
        <div className="flex gap-1">
          {attendance.is_late && (
            <span className="px-1.5 py-0.5 bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-400 rounded text-xs">L</span>
          )}
          {attendance.is_short_leave && (
            <span className="px-1.5 py-0.5 bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400 rounded text-xs">SL</span>
          )}
          {attendance.is_half_day && (
            <span className="px-1.5 py-0.5 bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-400 rounded text-xs">HD</span>
          )}
        </div>
      </td>
      <td className="px-4 py-3 text-sm">
        {!isEditing ? (
          <button
            onClick={() => setIsEditing(true)}
            className="p-1 text-blue-600 hover:text-blue-700 dark:text-blue-400 dark:hover:text-blue-300"
          >
            <Edit2 size={16} />
          </button>
        ) : (
          <div className="flex gap-1">
            <button
              onClick={handleSave}
              disabled={saving}
              className="p-1 text-green-600 hover:text-green-700 dark:text-green-400 dark:hover:text-green-300 disabled:opacity-50"
            >
              <Save size={16} />
            </button>
            <button
              onClick={handleCancel}
              disabled={saving}
              className="p-1 text-red-600 hover:text-red-700 dark:text-red-400 dark:hover:text-red-300 disabled:opacity-50"
            >
              <X size={16} />
            </button>
          </div>
        )}
      </td>
    </tr>
  );
}
