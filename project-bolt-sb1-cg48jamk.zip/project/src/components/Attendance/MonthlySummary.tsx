import { MonthlyAggregation } from '../../utils/attendanceCalculations';
import { Calendar, Clock, AlertCircle } from 'lucide-react';

interface MonthlySummaryProps {
  summary: MonthlyAggregation;
  month: string;
}

export function MonthlySummary({ summary, month }: MonthlySummaryProps) {
  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 mb-6">
      <div className="flex items-center mb-4">
        <Calendar className="w-5 h-5 mr-2 text-blue-600 dark:text-blue-400" />
        <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
          Monthly Summary - {month}
        </h3>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-gradient-to-br from-blue-50 to-blue-100 dark:from-blue-900/20 dark:to-blue-800/20 p-4 rounded-lg">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs text-blue-600 dark:text-blue-400 font-medium mb-1">Total Work Hours</p>
              <p className="text-2xl font-bold text-blue-900 dark:text-blue-300">{summary.totalWorkHours}</p>
            </div>
            <Clock className="w-8 h-8 text-blue-500 dark:text-blue-400 opacity-50" />
          </div>
        </div>

        <div className="bg-gradient-to-br from-green-50 to-green-100 dark:from-green-900/20 dark:to-green-800/20 p-4 rounded-lg">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs text-green-600 dark:text-green-400 font-medium mb-1">OT Hours</p>
              <p className="text-2xl font-bold text-green-900 dark:text-green-300">{summary.totalOTHours}</p>
            </div>
            <Clock className="w-8 h-8 text-green-500 dark:text-green-400 opacity-50" />
          </div>
        </div>

        <div className="bg-gradient-to-br from-orange-50 to-orange-100 dark:from-orange-900/20 dark:to-orange-800/20 p-4 rounded-lg">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs text-orange-600 dark:text-orange-400 font-medium mb-1">Lates</p>
              <p className="text-2xl font-bold text-orange-900 dark:text-orange-300">{summary.totalLates}</p>
              <p className="text-xs text-orange-500 dark:text-orange-400 mt-1">
                ({Math.floor(summary.totalLates / 4)} SL equiv.)
              </p>
            </div>
            <AlertCircle className="w-8 h-8 text-orange-500 dark:text-orange-400 opacity-50" />
          </div>
        </div>

        <div className="bg-gradient-to-br from-red-50 to-red-100 dark:from-red-900/20 dark:to-red-800/20 p-4 rounded-lg">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs text-red-600 dark:text-red-400 font-medium mb-1">Short Leaves</p>
              <p className="text-2xl font-bold text-red-900 dark:text-red-300">{summary.aggregatedShortLeaves}</p>
              <p className="text-xs text-red-500 dark:text-red-400 mt-1">
                ({Math.floor(summary.aggregatedShortLeaves / 2)} HD equiv.)
              </p>
            </div>
            <AlertCircle className="w-8 h-8 text-red-500 dark:text-red-400 opacity-50" />
          </div>
        </div>

        <div className="bg-gradient-to-br from-purple-50 to-purple-100 dark:from-purple-900/20 dark:to-purple-800/20 p-4 rounded-lg md:col-span-2">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs text-purple-600 dark:text-purple-400 font-medium mb-1">Half Days</p>
              <p className="text-2xl font-bold text-purple-900 dark:text-purple-300">{summary.aggregatedHalfDays}</p>
              <p className="text-xs text-purple-500 dark:text-purple-400 mt-1">Including aggregated leaves</p>
            </div>
            <AlertCircle className="w-8 h-8 text-purple-500 dark:text-purple-400 opacity-50" />
          </div>
        </div>

        <div className="bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-700 dark:to-gray-600 p-4 rounded-lg md:col-span-2">
          <div>
            <p className="text-xs text-gray-600 dark:text-gray-400 font-medium mb-2">Aggregation Rules</p>
            <ul className="text-xs text-gray-700 dark:text-gray-300 space-y-1">
              <li>• 4 Lates = 1 Short Leave</li>
              <li>• 2 Short Leaves = 1 Half Day</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
