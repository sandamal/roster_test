import { Attendance } from '../../lib/database.types';
import { AttendanceRow } from './AttendanceRow';

interface AttendanceTableProps {
  attendanceRecords: Attendance[];
  onUpdateAttendance: (id: string, arrivalTime: string, departureTime: string) => Promise<void>;
}

export function AttendanceTable({ attendanceRecords, onUpdateAttendance }: AttendanceTableProps) {
  if (attendanceRecords.length === 0) {
    return (
      <div className="text-center py-8 text-gray-500 dark:text-gray-400">
        No attendance records found for this period.
      </div>
    );
  }

  return (
    <div className="overflow-x-auto">
      <table className="w-full">
        <thead className="bg-gray-50 dark:bg-gray-700">
          <tr>
            <th className="px-4 py-3 text-left text-xs font-medium text-gray-700 dark:text-gray-300 uppercase tracking-wider">
              Date
            </th>
            <th className="px-4 py-3 text-left text-xs font-medium text-gray-700 dark:text-gray-300 uppercase tracking-wider">
              Shift
            </th>
            <th className="px-4 py-3 text-left text-xs font-medium text-gray-700 dark:text-gray-300 uppercase tracking-wider">
              Booth
            </th>
            <th className="px-4 py-3 text-left text-xs font-medium text-gray-700 dark:text-gray-300 uppercase tracking-wider">
              Arrival
            </th>
            <th className="px-4 py-3 text-left text-xs font-medium text-gray-700 dark:text-gray-300 uppercase tracking-wider">
              Departure
            </th>
            <th className="px-4 py-3 text-left text-xs font-medium text-gray-700 dark:text-gray-300 uppercase tracking-wider">
              OT Hours
            </th>
            <th className="px-4 py-3 text-left text-xs font-medium text-gray-700 dark:text-gray-300 uppercase tracking-wider">
              Status
            </th>
            <th className="px-4 py-3 text-left text-xs font-medium text-gray-700 dark:text-gray-300 uppercase tracking-wider">
              Actions
            </th>
          </tr>
        </thead>
        <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
          {attendanceRecords.map((attendance) => (
            <AttendanceRow
              key={attendance.id}
              attendance={attendance}
              onUpdate={onUpdateAttendance}
            />
          ))}
        </tbody>
      </table>
    </div>
  );
}
