-- Roster Generation Script for Gelanigama Interchange
-- This script generates a rotating roster for 3 teams over a specified date range
--
-- Rotation Pattern:
-- Team1: DAY -> DAY -> DAY -> DAY -> OFF -> OFF -> OFF -> OFF (8-day cycle)
-- Team2: NIGHT -> NIGHT -> NIGHT -> NIGHT -> OFF -> OFF -> OFF -> OFF (8-day cycle)
-- Team3: OFF -> OFF -> OFF -> OFF -> DAY -> DAY -> DAY -> DAY (8-day cycle)
--
-- Instructions:
-- 1. Replace the teller IDs and team assignments with your actual data
-- 2. Adjust the date range as needed
-- 3. Run this script in Supabase SQL Editor

-- Example data for 3 tellers (one per team)
-- You should expand this to include all your tellers

DO $$
DECLARE
  start_date DATE := '2026-02-01';
  end_date DATE := '2026-02-28';
  current_date DATE;
  day_offset INT;
  shift_type TEXT;
BEGIN
  current_date := start_date;

  WHILE current_date <= end_date LOOP
    day_offset := EXTRACT(DAY FROM (current_date - start_date));

    -- Team1: Day shift for days 0-3, Off for days 4-7 (8-day cycle)
    IF (day_offset % 8) < 4 THEN
      shift_type := 'Day';
    ELSE
      shift_type := 'Off';
    END IF;

    INSERT INTO roster (date, teller_id, team, shift, booth)
    VALUES (current_date, 'T001', 'Team1', shift_type,
            CASE WHEN shift_type = 'Off' THEN NULL ELSE 'Booth A' END)
    ON CONFLICT (date, teller_id) DO NOTHING;

    -- Team2: Night shift for days 0-3, Off for days 4-7 (8-day cycle)
    IF (day_offset % 8) < 4 THEN
      shift_type := 'Night';
    ELSE
      shift_type := 'Off';
    END IF;

    INSERT INTO roster (date, teller_id, team, shift, booth)
    VALUES (current_date, 'T002', 'Team2', shift_type,
            CASE WHEN shift_type = 'Off' THEN NULL ELSE 'Booth B' END)
    ON CONFLICT (date, teller_id) DO NOTHING;

    -- Team3: Off for days 0-3, Day shift for days 4-7 (8-day cycle)
    IF (day_offset % 8) >= 4 THEN
      shift_type := 'Day';
    ELSE
      shift_type := 'Off';
    END IF;

    INSERT INTO roster (date, teller_id, team, shift, booth)
    VALUES (current_date, 'T003', 'Team3', shift_type,
            CASE WHEN shift_type = 'Off' THEN NULL ELSE 'Booth C' END)
    ON CONFLICT (date, teller_id) DO NOTHING;

    current_date := current_date + INTERVAL '1 day';
  END LOOP;
END $$;

-- Verify the roster was created
SELECT date, teller_id, team, shift, booth
FROM roster
WHERE date >= '2026-02-01' AND date <= '2026-02-28'
ORDER BY date, team;

-- Sample manual insert for specific dates
-- Uncomment and modify as needed:
/*
INSERT INTO roster (date, teller_id, team, shift, booth) VALUES
  ('2026-02-01', 'T001', 'Team1', 'Day', 'Booth A'),
  ('2026-02-01', 'T002', 'Team2', 'Night', 'Booth B'),
  ('2026-02-01', 'T003', 'Team3', 'Off', NULL),
  ('2026-02-01', 'T004', 'Team1', 'Day', 'Booth D'),
  ('2026-02-01', 'T005', 'Team2', 'Night', 'Booth E'),
  ('2026-02-01', 'T006', 'Team3', 'Off', NULL)
ON CONFLICT (date, teller_id) DO NOTHING;
*/
